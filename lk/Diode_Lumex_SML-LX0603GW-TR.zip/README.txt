
EE Concierge + Altium Library Install Instruction:

The following are the instructions for loading a library that was exported from EE Concierge into Altium.

The library will come as a zip file filled with all the necessary Altium data files required to load your EE Concierge parts into Altium. For every part there will be a pcb file, and a schematic file. There will also be an index file, a readme file, and finally the master library file itself. Do not try to open any of the individual part files, or the index file as they can't be loaded on their own.

Instead, to load a library you simply need to point Altium to this master library file named: 'EEConcierge.DbLib'. There are two ways to do this which we outline below. Whenever you need to load an updated version of your EE Concierge library the instructions are exactly the same. We've tagged the parts exports in such a way that Altium will overwrite and update any previously loaded parts as opposed to creating duplicates.

Method A:

1) Unzip the exported library
2) Double click on the file 'EEConcierge.DbLib'
3) Altium will open and load the library for you, you can now use your new components

Method B:

1) Unzip the exported library
2) Open Altium Designer
3) In the 'File' menu, click 'Open'
4) Browse to the unzipped library directory, select 'EEConcierge.DbLib' and click 'Open'


Altium will load the library, you can now use your new components
Part SML-LX0603GW-TR (component id 2e690dbbc5599d02) experienced an error during datasheet export:
Traceback (most recent call last):
  File "/usr/lib/python2.7/dist-packages/upconvert/writer/altium/altium.py", line 354, in export_component
    datasheets[datasheet_url] = self.save_datasheet(datasheet_url)
  File "/usr/lib/python2.7/dist-packages/upconvert/writer/altium/altium.py", line 240, in save_datasheet
    r = requests.get(url, headers=headers, timeout=300)
  File "/usr/lib/python2.7/dist-packages/requests/api.py", line 70, in get
    return request('get', url, params=params, **kwargs)
  File "/usr/lib/python2.7/dist-packages/requests/api.py", line 56, in request
    return session.request(method=method, url=url, **kwargs)
  File "/usr/lib/python2.7/dist-packages/requests/sessions.py", line 475, in request
    resp = self.send(prep, **send_kwargs)
  File "/usr/lib/python2.7/dist-packages/requests/sessions.py", line 596, in send
    r = adapter.send(request, **kwargs)
  File "/usr/lib/python2.7/dist-packages/requests/adapters.py", line 497, in send
    raise SSLError(e, request=request)
SSLError: [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed (_ssl.c:590)


